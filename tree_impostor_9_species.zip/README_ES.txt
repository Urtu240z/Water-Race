TREE IMPOSTOR - 9 SPECIES

ESPECIES / ORDEN DEL ATLAS
0 Beech A
1 Beech B
2 Fir A
3 Fir B
4 Linden A
5 Linden B
6 Linden C
7 Oak A
8 Oak B

ARCHIVOS
- tree_impostor_atlas_builder.gd
- tree_impostor.gdshader

INSTALACION

1) Copia tree_impostor_atlas_builder.gd a:
   res://world/vegetation/trees/tree_impostor_atlas_builder.gd

2) Abre ese script en el Script Editor de Godot y ejecuta:
   File > Run
   o Ctrl+Shift+X

   Genera:
   res://world/vegetation/trees/textures/tree_atlas_tex.png
   res://world/vegetation/trees/textures/tree_atlas_mask.png
   res://world/vegetation/trees/textures/tree_atlas_nor.png

3) Sustituye:
   res://world/vegetation/trees/shaders/tree_impostor.gdshader
   por el shader incluido.

4) En el ShaderMaterial que usa el QuadMesh asigna:
   tree_tex    -> tree_atlas_tex.png
   tree_mask   -> tree_atlas_mask.png
   tree_normal -> tree_atlas_nor.png

   Mantén:
   volume_normal -> tree_volume_nor.png

5) Import:
   tree_atlas_tex.png:
     Compress > Mode = VRAM Compressed
     Mipmaps > Generate = On

   tree_atlas_mask.png:
     Compress > Mode = VRAM Compressed
     Mipmaps > Generate = On

   tree_atlas_nor.png:
     Compress > Mode = VRAM Compressed
     Mipmaps > Generate = On
     Normal Map = Enable

6) Material del MultiMesh:
   Species > Use Instance Species = On
   Leaf Variation > Use Instance Variation = On

NO HAY QUE TOCAR tree_impostor_multimesh.gd.

El sistema actual ya guarda un valor aleatorio por instancia en INSTANCE_CUSTOM.r.
El shader nuevo reutiliza ese valor:
- directamente para la variacion de hojas;
- pasado por un hash para seleccionar una especie estable.

Por eso no cambian las posiciones, Poisson, escalas ni el bake.

PESOS POR DEFECTO
Beech A 15
Beech B 10
Fir A 10
Fir B 5
Linden A 20
Linden B 10
Linden C 10
Oak A 15
Oak B 5

El builder crea atlas de 3072x3072:
- celda: 1024x1024
- padding: 32 px
- contenido por especie: 960x960

El padding evita que los mipmaps mezclen inmediatamente una especie con la celda vecina.
